Migration / Sync from other Software
------------------------------------

TBD

* Password Sync/Import
* Name/Details
* Groups

