## Author

* William Brown (Firstyear): william@blackhats.net.au

## Contributors

* Pando85
* Alberto Planas (aplanas)
* Jake (slipperyBishop)
* Charelle (Charcol)
* Leigh (excitedleigh)
* Jamie (JJJollyjim)
* Triss Healy (NiryaAestus)
* Samuel Cabrero (scabrero)
* Victor Wai (vcwai)
* James Hodgkinson (yaleman)

## Acknowledgements

* M. Gerstner
