// Don't allow setting class = recycle/tombstone during any
// operation unless internal == true OR delete.
