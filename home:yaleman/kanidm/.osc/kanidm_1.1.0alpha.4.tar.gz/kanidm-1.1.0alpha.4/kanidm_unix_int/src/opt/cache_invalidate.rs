
#[derive(Debug, StructOpt)]
struct CacheInvalidateOpt {
    #[structopt(short = "d", long = "debug")]
    debug: bool,
}

