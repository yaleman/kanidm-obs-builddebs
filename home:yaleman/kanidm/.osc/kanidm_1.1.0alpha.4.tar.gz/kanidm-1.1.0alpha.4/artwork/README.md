
About these artworks
--------------------

These artworks were commissioned and produced by Jesse Irwin (tw: @wizardfortress). They are very
much appreciated!

Both artworks are licensed as CC-BY-NC-ND.

